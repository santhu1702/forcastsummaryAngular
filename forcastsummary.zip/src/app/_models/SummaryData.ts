export interface SummaryData {
  sheetname:string;
  category: string;
  brand: string;
  year: number | null;
  salesType: string;
  _1: number | null;
  _2: number | null;
  _3: number | null;
  _4: number | null;
  _5: number | null;
  _6: number | null;
  _7: number | null;
  _8: number | null;
  _9: number | null;
  _10: number | null;
  _11: number | null;
  _12: number | null;
  _13: number | null;
}
