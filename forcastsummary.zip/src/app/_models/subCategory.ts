export interface subCategory {
  subCategory: string;
}
