export const environment = {
    production: false,
    apiUrl : 'https://localhost:7109/api/Excel/'
  };